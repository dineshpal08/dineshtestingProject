<!-- Please remove this file from your project -->
<template>
  <div>
<div class="top">
<button class="button button2">login</button>
</div>
<div class="header" style="text-align: center; margin: 50px;">
  <h3>Setup your company’s inventory management/ buying system in 3 steps</h3>
</div> 

<div>
  <p><b>Company Details</b></p>
  <p>Adding your company’s details is a mandatory step in registering your company</p>
</div>
<br><br>
<hr>
div
<div>
  <label for="companyname">Registered Company Name *</label>
  <input type="text" placeholder="F5 InfoTech"/>
</div>
<div>
  <label for="companyname">Pan No. *</label>
  <input type="text" placeholder="Enter the Company PAN no."/>
</div>
<div>
  <label for="companyname">Website URL *</label>
  <input type="text" placeholder="Enter the Company PAN no."/>
</div>
<div>
  <label for="companyname">Tan No.*</label>
  <input type="text" placeholder="Enter Company TAN no."/>
  <button class="button button2 upload">Upload</button>

</div>
<div>
  <label for="companyname">Your Nmae *</label>
  <input type="text" placeholder=" Enter Your Name"/>
</div>
<div>
  <label for="companyname">CIN NO. *</label>
  <input type="text" placeholder="Enter the CIN no."/>
  <button class="button button2 upload">Upload</button>

</div>
<div>
  <label for="companyname">Your Email ID *</label>
  <input type="text" placeholder="Enter your Email ID"/>
</div>
<div>
  <label for="companyname">GST NO. *</label>
  <input type="text" placeholder="Enter the Company GST no."/>
  <button class="button button2 upload">Upload</button>

</div>
<div>
  <label for="companyname">Your Mobile No. *</label>
  <input type="text" placeholder="Enter Your Mobile No."/>
</div>
<div>
  <label for="companyname">Cancelled cheque *</label>
  <button class="button button2 upload">Upload</button>

</div>
<div>
  <label for="companyname">Billing Address *</label>
  <textarea  placeholder="Enter the Company billing address" ></textarea>
</div>
<div>
  <label for="companyname">Company Registration Certificate *</label>
  <button class="button button2 upload">Upload</button>

</div>
<div>
  <label for="companyname">Managment Authorision *</label>
  <button class="button button2 upload">Upload</button>
</div>

<div>
  <button class=" button button3">Back</button>
  <button class=" button button3">Next ></button>
</div>

</div>
</template>

<script>
export default {
  name: 'NuxtTutorial',
  data () {
      return {
        e1: 1,
      }
    },
}
</script>

<style scoped>
.button2 {
  height: 40px;
  width: 100px;
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
  border-radius: 50px;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}
.top{
  height: 70px;
  padding: 15px;
  text-align: right;
  box-shadow: 1px 5px 5px rgb(118, 117, 117);
}
.color-blue{
  background-color: blue;
}
input{
  border: 2px solid black;
  height: 35px;
  margin: 10px;
}
textarea{
  border: 2px solid black;

}
.upload{
height: 30px;
width: 70px;
}

.button3 {
  height: 35px;
  width: 85px;
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;

}

</style>
