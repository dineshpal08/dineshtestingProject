<template>
  <Tutorial/>
</template>

<script>
import Tutorial from "../components/Tutorial.vue"
export default {
  name: 'IndexPage',
  components: { Tutorial }

 
}
</script>
